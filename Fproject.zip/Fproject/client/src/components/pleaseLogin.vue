<!-- PleaseLogin.vue -->
<template>
  <div class="please-login">
    <h1>Whoa there, Partner!</h1>
    <p>Looks like you've wandered off the trail. 🤠</p>
    <p>Don't worry, you can hitch your wagon back on track by moseying on over to the login page.</p>
    <h5>Just click your spurs <a href="http://localhost:3000/login">here</a> and you'll be back in the saddle in no time!</h5>
  </div>
</template>

<script>
import { useRouter } from 'vue-router';
export default {
  name: 'PleaseLogin',
}
</script>

<style scoped>
.please-login {
  background-color: white;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
  margin: 0;
  text-align: center;
}

h1 {
  font-size: 48px;
  color: black;
}

p, h5 {
  font-size: 20px;
  color: #333;
}

a {
  color: #007bff;
  text-decoration: none;
}

a:hover {
  text-decoration: underline;
}

</style>
