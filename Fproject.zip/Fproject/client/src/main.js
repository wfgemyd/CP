import { createApp } from 'vue'
import './styles/_index.sass'
import App from './App.vue'

import { createRouter, createWebHistory } from 'vue-router'
import LoginComponent from './components/login.vue';
import Onboarding from './components/onboarding.vue';
import Newticket from './components/new_ticket.vue';
import Tickets from './components/tickets.vue';
import Archive from './components/archive.vue';
import pleaseLogin from './components/pleaseLogin.vue';

const routes = [
    { path: '/login', component: LoginComponent },
    { path: '/onboarding', component: Onboarding },
    { path: '/new_ticket', component: Newticket },
    { path: '/tickets', component: Tickets },
    { path: '/archive', component: Archive},
    { path: '/pleaseLogin', component: pleaseLogin}
]

const router = createRouter({
    history: createWebHistory(process.env.BASE_URL),
    routes,
});
// Define a simple function to check if the user is authenticated
// This is just a placeholder. You need to implement actual logic based on your authentication method
function isAuthenticated() {
    // For example, check if there's a valid token in localStorage
    return !!localStorage.getItem('token');
}

// Add a global beforeEach guard
router.beforeEach((to, from, next) => {
    // Check if the route requires authentication by checking if it's not the login or pleaseLogin route
    if (to.path !== '/login' && to.path !== '/pleaseLogin' && !isAuthenticated()) {
        // Redirect the user to the pleaseLogin route
        next('/pleaseLogin');
    } else {
        // Proceed as normal if the user is authenticated or if it's a route that doesn't require authentication
        next();
    }
});

const app = createApp(App)
app.use(router)
app.mount('#app')

